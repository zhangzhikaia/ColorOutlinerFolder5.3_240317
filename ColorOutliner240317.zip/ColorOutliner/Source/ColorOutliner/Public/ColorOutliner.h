// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once
#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"
#include "SceneOutlinerFwd.h"

class SSceneOutlinerTreeRow;

class FColorOutlinerModule : public IModuleInterface
{
public:
	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

private:
	/*When map rename,change the saved path in config and TMap*/
	void RegisterOnMapRename();

	/*When map delete,clear the saved path in config and TMap*/
	void RegisterOnMapDeleted();

	/*When open/close/save map,update the saved data*/
	void RegisterOnMapChanged();

	/*When Outliner folders rename/move/delete,update the saved path in config and TMap*/
	void RegisterOnFolderOperate();
	
	void RegisterOutlinerItemLabelColumn();

	void RegisterOutlinerContextMenuExtend();
	
	/*On Set Color, Open color picker*/
	void OutlinerExecutePickColor();

	/*ColorPickerOnColorChanged,Call OnColorClick*/
	void OnLinearColorValueChanged(const FLinearColor InColor);

	/*Save Folder path and color in config */
	FReply OnColorClicked(const FLinearColor InColor);
	
	/*Clear folder path and color in config*/
	void OutlinerExecuteResetColor();

private:
	/*Current active SceneOutliner*/
	TWeakPtr<SSceneOutliner> SelectedSceneOutliner;
	/*All opened SceneOutliner window*/
	TArray<TWeakPtr<ISceneOutliner>> SceneOutliners;
	/*Selected Items in current active SceneOutliner*/
	TArray<FSceneOutlinerTreeItemPtr> ExecuteFolderItems;
	
private:
	/*DelegateHandle*/
	FDelegateHandle OnPreWorldRenameHandle;
	FDelegateHandle OnPostWorldRenameHandle;
	
	FDelegateHandle OnAssetsPreDeleteHandle;
	FDelegateHandle OnAssetsDeletedHandle;
	
	FDelegateHandle OnMapChangedHandle;
	
	FDelegateHandle OnFolderMovedHandle;
	FDelegateHandle OnFolderDeletedHandle;
};
