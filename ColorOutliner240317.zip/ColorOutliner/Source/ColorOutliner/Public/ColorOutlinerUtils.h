// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once
#include "ActorFolderTreeItem.h"

/*Debug macros*/
#if 0
#define DoubleToString UKismetStringLibrary::Conv_DoubleToString

#define Sleep(Frame) std::this_thread::sleep_for(std::chrono::milliseconds(Frame))

#define NewThread(Execute) std::thread([&]() {Execute}).detach()
#endif

/*Debug functions*/
#if 0
namespace Debug
{
	static void Print(const FString& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message);
		}
	}
	static void Print(const int32& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, FString::FromInt(message));
		}
	}
	static void Print(const FText& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message.ToString());
		}
	}
	static void FastPrint()
	{
		Print(TEXT("FastPring : Debug"));
	}
}
#endif

/*Utility*/
namespace SceneOutlinerFolderUtils
{
	FLinearColor GetOutlinerFolderDefaultColor();
	
	FName GetDefaultContextBaseMenuName();

	const FString GetFolderFullPath(const FActorFolderTreeItem* SelectedFolder);

	const FString GetFolderFullPath(const FFolder& Folder);
	
	TOptional<FLinearColor> GetFolderColor(const FString& FolderPath);

	/*OnColorClicked*/
	void SaveFolderColors(const FString& FolderPath, TOptional<FLinearColor> FolderColor);
	/*OnRowConstruct*/
	void SetRowWidgetColor(TSharedPtr<SWidget> RowWidget,const FLinearColor InColor);

	TOptional<FLinearColor> GetFolderColorTemp(const FString& FolderPath);

	/*OnColorClicked _ In temp map*/
	void SaveFolderColorsTemp(const FString& FolderPath, TOptional<FLinearColor> FolderColor);

	/*On Tear Down World*/
	void ClearFolderColorsTemp();

	/*On Temp map save as a map asset ,Take temp TMap property to config */
	void TempToSave(const UWorld* World);

	/*MapRename Event */
	/*OnPreWorldRename , save its old name , when renamed , find old name in config and replace its*/
	void SaveMapOldName(UWorld* World);
	/*OnPostWorldRename ,  find old name in config and replace its*/
	void OnWorldPathPostChanged(UWorld* World);

	/*MapDelete Event*/
	/*OnAssetsPreDelete , save its path , when deleted , find path in config and clear it.*/
	void SavePathPreDelete(const TArray<UObject*>& Objects);
	/*OnAssetsDeleted, find path in config and clear it. (assets was deleted, no path data , should save them before delete*/
	void OnWorldDeleted();

	/*FolderOperate Event*/
	/*OnFolderMoved , update path in config*/
	void UpdateFullPath(const FFolder& Source, const FFolder& Dest);
	/*OnFolderDeleted, delete path in config*/
	void DeleteFullPath(const FFolder& Folder);

	/*When open map,check it if temp map, save it bool*/
	void SetIsTempMap(const bool IsTemp);

	/*Is current map temp? */
	const bool GetIsTempMap();

	/*On LoadMap , Save current map's asset path to a FString*/
	void OLSetMapPath(const FString InMapPath);

	/*return now map's asset path*/
	FString OLGetMapPath();

	void SetIsFolderMoved(const bool IsMoved);

	const bool GetIsFolderMoved();
	
	/*OnClearFolderColor*/
	void DeleteFullPath(const FString InPath);
	/*OnClearFolderColor _ In temp map*/
	void DeleteFullPathTemp(const FString InPath);
}
